<?php

namespace App\Filament\Resources\DonasiResource\Pages;

use App\Filament\Resources\DonasiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDonasi extends CreateRecord
{
    protected static string $resource = DonasiResource::class;
}
