<?php

namespace App\Filament\Resources\SiswaRaResource\Pages;

use App\Filament\Resources\SiswaRaResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSiswaRa extends CreateRecord
{
    protected static string $resource = SiswaRaResource::class;
}
